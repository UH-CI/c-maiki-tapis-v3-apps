#!/usr/bin/env Rscript
source("/workspace/util.R")

# Extract no chimera sequences and store into an R object for dada2
extract_chimeras("SRR5314333_R1.fastq.gz_R12_derep.RDS","SRR5314333_R1.fastq.gz_R12_noChimeras.fasta","SRR5314333_R1.fastq.gz")

# Build error model
learn_error_rates("SRR5314333_R1.fastq.gz_R12_nochimera.RDS","SRR5314333_R1.fastq.gz",rds=TRUE)
