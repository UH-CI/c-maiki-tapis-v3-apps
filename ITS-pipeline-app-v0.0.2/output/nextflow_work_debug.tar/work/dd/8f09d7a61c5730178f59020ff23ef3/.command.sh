#!/usr/bin/env python3
from Bio import SeqIO
import pandas as pd

ids = pd.read_csv("lulu_ids_100.csv", header=None)[0].values
sequences = [ seq for seq in SeqIO.parse("all_esv.fasta","fasta") if seq.id.split(";")[0] in ids ]
SeqIO.write(sequences,"sequences_100.fasta","fasta")
