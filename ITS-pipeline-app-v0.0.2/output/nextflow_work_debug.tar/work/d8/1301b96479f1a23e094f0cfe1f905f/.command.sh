#!/usr/bin/env bash

read_pair=(SRR5314333_R1.fastq.gz)

rev_arg=$([ false == true ] && echo "--fastq2 ${read_pair[1]}" || echo "--single_end")

itsxpress --region ITS1 --threads 1     	      --outfile SRR5314333_R1.fastq.gz_ITS1.fastq --log ITSxpress_SRR5314333_R1.fastq.gz.log               --fastq ${read_pair[0]} ${rev_arg}
