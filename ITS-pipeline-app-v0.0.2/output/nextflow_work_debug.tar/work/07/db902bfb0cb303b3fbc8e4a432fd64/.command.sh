#!/bin/bash -ue
vsearch --threads 1 		--uchime3_denovo SRR5314331_R1.fastq.gz_R12_derep.fasta 		--sizein 		--sizeout 		--fasta_width 0 		--nonchimeras SRR5314331_R1.fastq.gz_R12_noChimeras.fasta
