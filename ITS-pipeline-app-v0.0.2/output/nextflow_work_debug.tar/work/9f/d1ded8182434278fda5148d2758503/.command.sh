#!/usr/bin/env Rscript
source("/workspace/util.R")

esv_table(paired=FALSE)
merge_fasta_for_vsearch("raw_sequence_table.csv")
