#!/bin/bash -ue
vsearch --usearch_global all_esv.fasta             --threads 2             --db all_esv.fasta --self             --id .84             --iddef 1             --userout match_list_100.txt             -userfields query+target+id             --maxaccepts 0             --query_cov .9             --maxhits 10
