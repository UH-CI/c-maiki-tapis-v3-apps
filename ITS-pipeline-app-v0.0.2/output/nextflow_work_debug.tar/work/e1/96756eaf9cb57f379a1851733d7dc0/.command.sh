#!/usr/bin/env Rscript 
library(dada2)

derep <- derepFastq("SRR5314332_R1.fastq.gz_filtered.fastq.gz")
saveRDS(derep,"SRR5314332_R1.fastq.gz_R12_derep.RDS")
uniquesToFasta(derep,"SRR5314332_R1.fastq.gz_R12_derep.fasta")
