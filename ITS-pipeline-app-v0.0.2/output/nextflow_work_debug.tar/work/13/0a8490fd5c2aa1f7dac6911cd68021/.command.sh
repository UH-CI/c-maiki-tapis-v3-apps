#!/usr/bin/env Rscript
source("/workspace/util.R")

lulu_curate("clustering_100.csv","match_list_100.txt","100","min","1","97","1")
