#!/bin/bash -ue
vsearch --threads 2             --cluster_size esv_merged_to_cluster.fasta             --id 0.97             --strand plus             --sizein             --sizeout             --fasta_width 0             --uc clusters97.uc             --relabel OTU97_             --centroids OTUs_97.fasta             --otutabout clustering_97.tsv

cat clustering_97.tsv | tr "\t" "," > clustering_97.csv
