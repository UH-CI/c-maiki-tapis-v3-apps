#!/usr/bin/env Rscript
source("/workspace/util.R")

lulu_curate("clustering_97.csv","match_list_97.txt","97","min","1","97","1")
