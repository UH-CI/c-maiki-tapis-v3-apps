#!/usr/bin/env python3
from generate_step_summary import write_summary

clustering_threshold = [100, 97]
counts = { '0-RawData': {'SRR5314331_R1.fastq.gz': 1000, 'SRR5314333_R1.fastq.gz': 1000, 'SRR5314332_R1.fastq.gz': 1000},
           '1-ITSxpress': {'SRR5314332_R1.fastq.gz': 167, 'SRR5314331_R1.fastq.gz': 172, 'SRR5314333_R1.fastq.gz': 196},
           '2-NandSmallSeqsFiltering': {'SRR5314333_R1.fastq.gz': 196, 'SRR5314331_R1.fastq.gz': 172, 'SRR5314332_R1.fastq.gz': 167},
           '3-QualityFiltering': {'SRR5314331_R1.fastq.gz': 167, 'SRR5314333_R1.fastq.gz': 191, 'SRR5314332_R1.fastq.gz': 157}
         }

steps = [("0-RawData", -1),
         ("1-ITSxpress",-1),
         ("2-NandSmallSeqsFiltering",-1),
         ("3-QualityFiltering",-1),
         ("7-Clustering","clustering_*.csv"),
         ("8-LULU_correction","all_lulu_*.csv")                                         
]

write_summary(steps,counts,clustering_threshold)
