#!/bin/bash -ue
vsearch --usearch_global OTUs_97.fasta             --threads 2             --db OTUs_97.fasta --self             --id .84             --iddef 1             --userout match_list_97.txt             -userfields query+target+id             --maxaccepts 0             --query_cov .9             --maxhits 10
