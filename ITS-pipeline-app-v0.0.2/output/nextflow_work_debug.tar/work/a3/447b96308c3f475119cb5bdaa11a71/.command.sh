#!/bin/bash -ue
fastq_quality_filter -z -q 25                             -p 90                             -i SRR5314333_R1.fastq.gz_noN.fastq                             -o SRR5314333_R1.fastq.gz_filtered.fastq.gz
