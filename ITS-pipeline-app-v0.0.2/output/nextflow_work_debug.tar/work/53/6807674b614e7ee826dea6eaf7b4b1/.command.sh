#!/bin/bash -ue
vsearch --threads 2 --db unite_all_eukaryotes.fasta             --sintax sequences_100.fasta --sintax_cutoff 0.5             --tabbedout annotations_sintax_100.tsv
