#!/usr/bin/env Rscript
source("/workspace/util.R")

dada_denoise("SRR5314333_R1.fastq.gz_errors.RDS","SRR5314333_R1.fastq.gz_R12_nochimera.RDS","SRR5314333_R1.fastq.gz_R12",derep.rds=TRUE,paired=FALSE)
