#!/usr/bin/env python3
from Bio import SeqIO
import pandas as pd

ids = pd.read_csv("lulu_ids_97.csv", header=None)[0].values
sequences = [ seq for seq in SeqIO.parse("OTUs_97.fasta","fasta") if seq.id.split(";")[0] in ids ]
SeqIO.write(sequences,"sequences_97.fasta","fasta")
