#!/usr/bin/env python3
from Bio import SeqIO

seqs = [ seq for seq in SeqIO.parse("SRR5314333_R1.fastq.gz_ITS1.fastq","fastq")
         if "N" not in seq.seq and len(seq) > 20 ]

SeqIO.write(seqs, "SRR5314333_R1.fastq.gz_noN.fastq", "fastq")
